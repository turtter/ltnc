#include<iostream>
#include<cmath>

using namespace std;

int main()
{
    int a, b;
    cout <<"Cho phan so a:" << endl;
    cout <<"Tu: ";
    cin >> a;
    cout <<"Mau: ";
    cin >> b;

    if(b != 0)
    {
        cout <<"Chuan hoa           "
    }
}