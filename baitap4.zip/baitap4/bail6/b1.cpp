#include<iostream>
#include<string>

using namespace std;

int main()
{
    int a[100];
    int n;
    cout <<"N = ";
    cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout <<"a[" << i <<"] = ";
        cin >> a[i];
    }

    cout <<"Day A =";
    for(int i = 0; i < n; i++)
    {
       cout << " "<< a[i];
    }    cout << endl;
    
    int dem = 0;
    for(int i = 0; i < n; i++)
    {
        if(a[i] < 0)
        {
            dem++;
        }
    }
    cout <<"So so am trong A: " << dem << endl;

   
    return 0;
}