#include<iostream>
#include<string>
#include<cmath>

using namespace std;

int main()
{
    float a[100];
    int n;
    cout <<"N = ";
    cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout <<"a[" << i <<"] = ";
        cin >> a[i];
    }

    float min = a[0];
    for(int i = 1; i < n; i++)
    {
        if(a[i] < min)
        {
            min = a[i];
        }
    }
        cout <<"Gia tri nho nhat trong A: "<< min;

    
    return 0;
}