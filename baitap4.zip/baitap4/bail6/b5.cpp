#include<iostream>
#include<string>
#include<cmath>

using namespace std;

int main()
{
    int a[100000];
    int n;
    cout <<"N = ";
    cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout <<"a[" << i <<"] = ";
        cin >> a[i];
    }

    int max = a[0];
    for(int i = 0; i < n; i++)
    {
        if(max < a[i])
        {
            max = a[i];
        } 
    }

    int dem = 0;
    for(int i = 0; i < n; i++)
    {
        if(a[i] == max)
        {
            dem++;
        }
    }
    
        cout <<"Gia tri lon nhat cua A: "<< max;
        cout <<"\nSo phan tu co gia tri lon nhat: " << dem;
        
    //system("pause");
    return 0;
}
