#include<iostream>
#include<cmath>
#include<string>

using namespace std;

int main()
{
    float a[1000];
    int n;
    cout <<"N = ";
    cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout <<"A[" << i <<"] = ";
        cin >> a[i];
    }

    
    cout <<"Cac phan tu o vi tri chan:";
    for(int i = 0; i < n; i+= 2)
    {
        cout <<" " << a[i];
    }
    //cout << endl;
    
    //system("pause");
    return 0;
}
