#include<iostream>
#include<string>

using namespace std;

int main()
{
    int n;
    int a[1000];
    do
    {
        cout <<"Cho n = ";
        cin >> n;
    } while (n < 5 || n > 99);
    
    for(int i = 0; i < n; i++)
    {
        cout <<"Nhap phan tu " << i + 1 <<": ";
        cin >>a[i];
    }

    int x;
    cout <<"Cho x = ";
    cin >> x;
    cout <<"Hay them x vao dau danh sach!" << endl;
    
    cout <<"In danh sach: " << x;
    for(int i = 0; i < n; i++)
    {
        cout << " " << a[i];
    }      
        cout << endl;
    
    int tong = 0;
    for(int i = 0; i < n; i++)
    {
        if(a[i] % 2 == 0)
        {
            tong = tong + a[i];
        }
    }
    if(x % 2 == 0)
    {
        tong = tong + x;
    }
        cout <<"Tong cac so chan: " << tong << endl;

        //system("pause");
        return 0;
}