#include<iostream>
#include<cmath>

using namespace std;

bool checknt(int n)
{
    if (n < 2)
    {
        return false;
    }

    for (int i = 2; i <= sqrt(n); i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }

    return true;
}

void Inds(int n)
{
    for (int i = 0; i < n; i++)
    {
        if (checknt(i) == true)
        {
            cout << " " << i;
        }
    }
}

int main()
{
    int n, x;

    do
    {
        cout << "Cho n = ";
        cin >> n;
    } while (n < 9 || n > 100);

    cout << "Hien thi lai danh sach:";
    Inds(n);

    cout << endl;
    cout << "Cho so nguyen x = ";
    cin >> x;

    if (checknt(x) == false) {
        cout << "x khong phai la so nguyen to!" << endl;
        cout << "Hien thi lai danh sach:";
        Inds(n);
        return 0;
    } else {
        cout << "x la so nguyen to. Hay them x vao dau danh sach." << endl;
        cout << "Hien thi lai danh sach: " << x;
        Inds(n);
    }

    //system("pause");
    return 0;
}