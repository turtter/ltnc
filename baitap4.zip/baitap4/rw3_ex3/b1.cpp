#include<iostream>
#include<string>

using namespace std;

int main()
{
    int n;
    float a[10000];
    
    do
    {
        cout <<"Cho N = ";
        cin >> n;
    } while (n < 0 || n > 99);

    for(int i = 0; i < n; i++)
    {
        cout <<"Phan tu thu " << i+1 <<": ";
        cin >>a[i];
    }
    
    cout <<"Danh sach:";
    for(int i = 0; i < n; i++)
    {
        cout << " " << a[i];
    }   
        cout << endl;

    float x;
    cout <<"Cho x = ";
    cin >> x;

    cout <<"Danh sach:";
    for(int i = 0; i < n; i++)
    {
        cout << " " << a[i];
    }   cout <<" "<< x << endl;
    
    //system("pause");
    return 0;
}