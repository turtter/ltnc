#include<iostream>
#include<string>
#include<cmath>

using namespace std;

int main()
{
    float a[10000];
    int n;
    do
    {
        cout <<"Cho so phan tu n = ";
        cin >> n;
    } while (n < 5);
    
    for(int i = 0; i < n; i++)
    {
        cout <<"Nhap phan tu thu " << i+1 <<": ";
        cin >> a[i];
    }
        cout << endl;
    
    cout <<"Hien thi danh sach:";
    for(int i = 0; i < n; i++)
    {
        cout <<" " << a[i];
    }
        cout << endl;

    float x;
    cout <<"Cho x = ";
    cin >> x;
    cout <<"Hay them x vao dau va cuoi danh sach." << endl;
    cout <<"Hien thi danh sach: " << x;
    for(int i = 0; i < n; i++)
    {
        cout <<" " << a[i];
    }   cout <<" " << x << endl;

    cout <<"Hay xoa o cuoi danh sach:" << endl;
    cout <<"Hien thi danh sach: " << x;
    for(int i = 0; i < n; i++)
    {
        cout <<" " << a[i];
    }   cout << endl;
    
    int dem = 0;
    for(int i = 0; i < n; i++)
    {
        dem++;
    }
        cout <<"Do dai cua DS = " << dem +1 << endl;

    //system("pause");
    return 0;    
}