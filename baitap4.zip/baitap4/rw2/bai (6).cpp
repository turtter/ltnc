#include<iostream>
#include<cmath>

using namespace std;

int main()
{
	double e, x;
	cout << "Sai so e = ";
	cin >> e;
	
	if (e < 0 || e > 0.99)
	{
		cout << "e khong thoa man!";
		return 0;
	}
	
	cout << "x = ";
	cin >> x;
	
	double s = 0, i = 1;
	// n	1/3    0.3
	//n + 1 1/4    0.25
	while (1 / i >= e)
	{
		s += pow(x, i - 1) / i;
		i++;	
	} 
	
	cout << "Tong S = " << s;
	return 0;
}
