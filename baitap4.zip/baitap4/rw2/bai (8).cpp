#include<iostream>

int C(int k, int n)
{
	if (k == 0 || k == n)
	{
		return 1;
	}
	
	if (k == 1)
	{
		return n;
	}
	
	return C(k - 1, n - 1) + C(k, n - 1);
}

int main()
{
	int n, k;
	std::cout << "n = ";
	std::cin >> n;
	std::cout << "k = ";
	std::cin >> k;
	
	if (k <= 0 || n <= k)
	{
		std::cout << "So lieu khong hop le";
		return 0;
	}
	
	std::cout << "C(" << k << "," << n << ") = " << C(k, n);
	return 0;
}
