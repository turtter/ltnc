#include<iostream>
#include<cmath>

using namespace std;

int Fibo(int n)
{
	if (n > 0 && n <= 2)
	{
		return 1;
	}
	
	return Fibo(n - 1) + Fibo(n - 2);
}	

int main()
{
	int n;
	
	do
	{
		cout << "N = ";
		cin >> n;
	} while (n < 1 || n > 19);
	
	cout << "So Fibonacci thu " << n << " la: " << Fibo(n);
	return 0;
}
