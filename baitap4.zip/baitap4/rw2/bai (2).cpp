#include<iostream>
#include<cmath>

using namespace std;

bool nt(int n) // n = 17
{
	if (n < 2)
	{
		return false;
	}
						// 40
	for (int i = 2; i <= sqrt(n); i++)
	{
		// So nguyen to chi chia het cho 1
		// hoac chinh no.
		// Neu chia het cho bat ki so nao
		// trong khoang nay -> khong phai so nguyen to.
		if (n % i == 0)
		{
			return false;
		}
	}
	
	return true;
}

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	
	cout << "Cac so nguyen to:";
	for (int i = 0; i < n; i++)
	{
			// 17
		if (nt(i) == true)
		{
			cout << " " << i;
		}
	}
	return 0;
}
