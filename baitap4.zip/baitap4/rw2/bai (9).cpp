#include<iostream>
#include<cmath>

using namespace std;

bool cp(int n)
{
	int x = sqrt(n);
	return x * x == n ? true:false;
}

int main()
{
	int n;
	cout << "Nhap N = ";
	cin >> n;
	
	if (n <= 0)
	{
		cout << "n khong duong!";
		// Thoat
		return 0;
	}	
	
	cout << "So chinh phuong:";
	
	for(int i = 0; i < n; i++)
	{
		if (cp(i) == true)
		{
			cout << " " << i;
		}
	}
	
	return 0;
}
