#include<iostream>

using namespace std;

int main()
{
	int n;
	cout << "N = ";
	cin >> n;
	
	if (n < 2 || n > 19)
	{
		cout << "n khong thoa man!";
		return 0;
	}
	
	int tong = 1;
	for (int i = 2; i <= n; i++)
	{
		// +=
		// tong += i;
		// tong = tong + i;
		tong += (i - 1) * i * (i + 1);
	}
	
	cout << "Tong A = " << tong;
	return 0;
}
