#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	string m[100], t[100], n[100];
	int i=1;
	do
	{
		cout << "Nhap MaSV: "; getline(cin,m[i]);
		if (m[i].size() != 0)
		{
			cout << "Nhap ten: "; getline(cin, t[i]);
			cout << "Nam sinh: "; getline(cin, n[i]);
		
		}
		i++;
	}while(m[i - 1].size() != 0);
	i--;
	cout << "Hien thi danh sach:\n";
	for(int j = 1; j <i; j++)
	cout << m[j] << '\t' << t[j] << '\t' << n[j] << '\n';
	cout << "Cho SV can them vao dau DS:\n";
	cout << "MaSV: "; getline(cin, m[0]);
	cout << "Ten: "; getline(cin, t[0]);
	cout << "Nam sinh: "; getline(cin, n[0]);
	cout << "Hien thi danh sach:\n";
	for(int j = 0; j <i; j++)
		cout << m[j] << '\t' << t[j] << '\t' << n[j] << '\n';
	return 0;
}
