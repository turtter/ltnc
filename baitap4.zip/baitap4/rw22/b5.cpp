#include <iostream>
#include <string>

using namespace std;

int main()
{
	int n;
	do{
		cout <<"Cho N = "; cin >> n;
	}while(n <= 0 || n >= 100);

	string t[n + 1];
	float d[n+1];
	for(int i=0; i<n; i++)
	{
		cin.ignore();
		cout << "Ho va ten: "; getline(cin, t[i]);
		cout << "Diem: "; cin >> d[i];
		while(d[i] < 0 || d[i]>10){
			cout << "Nhap lai diem thi!\n";
			cout << "Diem: "; cin >> d[i];	
		}
	}
	cout << "Thong tin sinh vien them vao DS:\n";
	cin.ignore();
	cout << "Ho va Ten: "; getline(cin, t[n]);
	cout << "Diem thi: "; cin >> d[n];
		while(d[n] <0||d[n]>10){
			cout << "Nhap lai diem thi!\n";
			cout << "Diem thi: "; cin >> d[n];	
		}
	cout << "In lai danh sach:\n";
	for(int i = 0; i <=n; i++)
	cout << t[i] <<'\t'<<d[i]<<'\n';
	return 0;
}
