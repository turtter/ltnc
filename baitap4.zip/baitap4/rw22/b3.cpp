#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	float ta, ma, tb, mb;
	cout << "Cho so phuc z1:\n";
	cout << "Phan thuc: "; cin >> ta;
	cout << "Phan ao: "; cin >> ma;
	cout << "Cho so phuc z2:\n";
	cout << "Phan thuc: "; cin >> tb;
	cout << "Phan ao: "; cin >> mb;
	cout << "z1 + z2 = " << ta + tb << " + " << ma + mb << "i";
	cout << "\nz1 * z2 = " << ta*tb - ma*mb << " + " << ta*mb + ma*tb << "i";
	
}
