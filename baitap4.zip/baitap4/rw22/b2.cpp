#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	int ta, ma, tb, mb;
	cout << "Cho phan so a:\n";
	cout << "Tu: "; cin >> ta;
	cout << "Mau: "; cin >> ma;
	if (ma == 0) 
		cout << "Phan so khong hop le!";
	else
	{
		cout << "Chuan hoa phan so: ";	
		if ((ta < 0 || ma < 0) && ta*ma <0) cout << '-';
		int c = __gcd(abs(ta), abs(ma));
		cout << abs(ta) / c << '/' << abs(ma)/c;
	}
}
