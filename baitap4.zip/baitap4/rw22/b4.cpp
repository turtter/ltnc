#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	int ta, ma, tb, mb;
	cout << "Phan so a:\n";
	cout << "Tu: "; cin >> ta;
	cout << "Mau: "; cin >> ma;
	cout << "Phan so b:\n";
	cout << "Tu: "; cin >> tb;
	cout << "Mau: "; cin >> mb;
	if (ma == 0 || mb == 0) 
		cout << "Co phan so khong hop le!";
	else
	{
	
		cout << "Hieu a - b = ";	
		int  t = ta*mb - tb*ma, m = ma*mb;
		if ((t < 0 || m < 0) && t*m < 0) cout << '-';
		int c = __gcd(abs(t), abs(m));
		cout << abs(t) / c << '/' << abs(m )/c;
	}
}
