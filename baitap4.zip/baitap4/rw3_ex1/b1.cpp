#include<iostream>
#include<cstring>
#include<cmath>

using namespace std;

int main()
{
    string a[10000];
    int n;
    do
    {
        cout <<"N = ";
        cin >> n; 
    } while (n < 1 || n > 9);
            getline(cin, a[0]);
    
    for(int i = 1; i <= n; i++)
    {
        cout << "Ho ten thu " << i << ": ";
        getline(cin, a[i]);
    }

    string min = a[1];
    for(int i = 1; i <= n; i++)
    {
        if(min.length() > a[i].length())
        {
            min = a[i];
        }
    }
        cout <<"Ho ten ngan nhat (dau tien): " << min << endl;

    //system("pause");
    return 0;
}