#include<iostream>
#include<string>

using namespace std;

int dem(string a)
{
    int dem = 0;
    for(int i = 0; i < a.length(); i++)
    {
        if(a[i] != ' ' && a[i+1] == ' ' || a[i] != ' ' && a[i+1] == '\0')
        {
            dem++;
        }
    }
        return dem;
}

int main()
{
    string a;
    cout <<"Nhap xau S:";
    getline(cin , a);

    cout <<"So tu cua S:" << dem(a) << endl;

    cout <<"Xau S sau khi xoa:";
    for(int i = 0; i < a.length(); i++)
    {
        if(isdigit(a[i]))
        {
            a.erase(i, 1);
            i--;
        }
    } cout << a;
        cout << endl;

    //system("pause");
    return 0;
    }