#include<iostream>
#include<string>

using namespace std;

int dem(string a)
{
    int dem = 0;
    for(int i = 0; i < a.length(); i++)
    {
        if(a[i] != ' ' && a[i+1] == ' ' || a[i] != ' ' && a[i+1] == '\0')
        {
            dem++;
        }
    } return dem;
}

int main()
{
    string a;
    cout <<"Nhap xau S:";
    getline(cin, a);
    int tu = dem(a);

    for(int i = 0; i < a.length(); i++)
    {
        if(!isalpha(a[i]) && !isdigit(a[i]) && a[i] != ' ' )
        {
            a.erase(i, 1);
            i--;
        }
    } 
        cout <<"Xau S sau khi xoa:" << a << endl;
        cout <<"So tu cua S:" << tu;
    
    //system("pause");
    return 0;
}