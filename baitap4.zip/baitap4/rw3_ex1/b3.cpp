#include<iostream>
#include<cstring>

using namespace std;

int dem(string a)
{
    int dem = 0;
    for(int i = 0; i < a.length(); i++)
    {
        if(a[i] != ' ' && a[i+1] == ' ' || a[i] != ' ' && a[i+1] == '\0')
        {
            dem++;
        }
    }
        return dem;
}

int main()
{
    string a,w;

    cout <<"Nhap xau S:";
    getline(cin, a);

    cout <<"So tu cua S: " << dem(a) << endl;
    cout << "Nhap xau W:";
    getline(cin, w);

    if(a.find(w) <= a.length())
    {
        cout << "Xau W xuat hien trong S tai vi tri: " << a.find(w);
    } else{
        cout << "Xau W khong xuat hien trong S!";
    }
    //system("pause");
}