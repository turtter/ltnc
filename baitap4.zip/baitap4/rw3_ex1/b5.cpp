#include<iostream>
#include<string>

using namespace std;

int dem(string a)
{
    int dem = 0;
    for(int i = 0; i < a.length(); i++)
    {
        if(a[i] != ' ' && a[i+1] == ' ' || a[i] != ' ' && a[i+1] == '\0')
        {
            dem++;
        }
    }   return dem;
}

int main()
{
    string a;
    cout <<"Nhap xau S:";
    getline(cin , a);
    
    if(a.length() == 0)
    {
        cout <<"Xau rong!";
        return 0;
    }

    cout <<"So tu cua S: " << dem(a) << endl;

    int dem1;
    for(int i = 0; i < a.length(); i++)
        {
            if(!isdigit(a[i]) && !isalpha(a[i]))
            {
                dem1++;
            }
        }
    
    for(int i = 0; i < a.length(); i++)
    {
        if(!isdigit(a[i]) && !isalpha(a[i]))
        {
            a.erase(i, 1);
            i--;
        }
    }
    	cout <<"So ky tu khong la chu cai/chu so: " << dem1 << endl;
        cout <<"Xau S sau khi xoa:" << a;

    //system("pause");
    return 0;
}
