#include<iostream>
#include<cstring>

using namespace std;

string chuanhoa(string s)
{
    while (s[0] == ' ')
    {
        s.erase(0, 1);
    }

    while(s[s.size() - 1] == ' ')
    {
        s.erase(s.size() - 1, 1);
    }

    int i = 0;
    while (i < s.size()) {
        if (s[i] == ' ' && s[i + 1] == ' ')
        {
            s.erase(i, 1);
        } else {
            i++;
        }
    }

    return s;
}

int dem(string s)
{
    int dem = 0, i = 0;

    for (int i = 0; i < s.size(); i++)
    {
        if (s[i] != ' ' && s[i + 1] == ' '||
            s[i] != ' ' && s[i + 1] == '\0')
        {
            dem++;
        }
    }

    return dem;
}

int main()
{
    string s;
    cout << "Nhap xau:";
    getline(cin, s);

    if (s.length() == 0) {
        cout << "Xau rong!";
        return 0;
    } else {
        cout << "Chuan hoa:" << chuanhoa(s) << endl;
        cout << "So tu:" << dem(chuanhoa(s)); 
    }

    return 0;
}