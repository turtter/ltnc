#include<iostream>
#include<string>
#include<cmath>

using namespace std;

int main()
{
    int n;
    do
    {
        cout <<"Cho n = ";
        cin >> n;
    } while( n < 20);

    cout <<"Hien thi danh sach:";
    for(int i = 1; i <= n; i++)
    {
        if(i % 2 == 0)
        {
            cout <<" " << i;
        }
    }   cout << endl;

    int x;
    cout <<"Cho so nguyen x = ";
    cin >> x;
    
    int tong = x;
    if(x % 2 == 0)
    {
        cout << "Them x vao dau danh sach!" << endl;
        cout <<"Hien thi danh sach: ";
        cout << x;

        for(int i = 1; i <= n; i++)
        {
            if(i % 2 == 0)
            {
                cout <<" " << i;
                tong = tong + i;
            }
        }   
    } else {
        cout <<"Them x vao cuoi danh sach!" << endl;
        cout <<"Hien thi danh sach:";
        for(int i = 1; i <= n; i++)
        {
            if(i % 2 == 0)
            {
                cout <<" " << i;
                tong = tong + i;
            } 
        }  
            cout << " " << x;
    }
        cout << endl;
    cout <<"Tong cac phan tu: " << tong << endl;;

    //system("pause");
    return 0;
}
