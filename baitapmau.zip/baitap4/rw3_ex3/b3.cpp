#include<iostream>
#include<string>
#include<cmath>

using namespace std;

int main()
{
    float a[10000];
    int n;
    do
    {
        cout <<"Cho n = ";
        cin >> n;
    } while (n < 5 || n > 99);

    for(int i = 0; i < n; i++)
    {
        cout <<"Nhap phan tu thu " << i +1 <<": ";
        cin >> a[i];
    }    

    cout <<"Hien thi danh sach:";
    for(int i = 0; i < n; i++)
    {
        cout << " " << a[i];
    }
        cout << endl;

    cout <<"Hay xoa phan tu o dau va cuoi danh sach!" << endl;
    
    float tong = 0;
    cout <<"Hien thi danh sach:";
    for(int i = 1; i < n-1; i++)
    {
        cout <<" " << a[i];
        tong = tong + a[i];
    }
        cout << endl;

    float x;
    cout <<"Cho x = ";
    cin >> x;
    cout << endl;

    cout <<"Hay them x vao dau va cuoi danh sach!" << endl;
    cout <<"Hien thi danh sach: " << x;
    for(int i = 1; i < n-1; i++)
    {
        cout <<" " << a[i];
    }   cout <<" " << x;
 
        cout <<endl;
        cout <<"Tong cac phan tu: " << tong + x + x << endl;

    //system("pause");
    return 0;
}