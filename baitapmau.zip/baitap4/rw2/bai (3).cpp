#include<iostream>
#include<cmath>

using namespace std;

int main()
{
	int n;
	cout << "N = ";
	cin >> n;
	
	if (n < 2 || n > 99)
	{
		cout << "n khong thoa man!";
		return 0;
	}
	
	// Khong the lay so nguyen chia so thap phan, va nguoc lai.
	// Chuyen tu nguyen -> thuc: i * 1.00.
	double s = 1;
	for (double i = 2; i <= n; i++)
	{
		s += 1 / ((i - 1) * i);
	}
	
	cout << "Tong S = " << s;
	return 0;
}
