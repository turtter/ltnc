#include<iostream>

using namespace std;

int main()
{
	double e;
	cout << "Sai so e = ";
	cin >> e;
	
	if (e < 0 || e > 0.99)
	{
		cout << "e khong thoa man!";
		return 0;
	}
	
	double s = 0, i = 1;
	while (1 / i >= e)
	{
		s += 1 / i;
		i++;	
	} 
	
	cout << "Tong S = " << s;
	return 0;
}
