#include<iostream>
#include<cmath>

using namespace std;

int main()
{
	int n;
	double x;
	
	cout << "n = ";
	cin >> n;
	
	cout << "x = ";
	cin >> x;
	
	if (n < 1 || n > 19)
	{
		cout << "n khong thoa man!";
		return 0;
	}
	
	double tong = 1;
	
	for (double i = 2; i <= n; i++)
	{
		tong += pow(x, i - 1) / i;
	}
	
	cout << "Tong S = " << tong;
	return 0;
}
